
document.addEventListener("DOMContentLoaded", function () {
  docReady();
  //Aquesta constant simbolitza la velocitat.
  //Realment és el número de píxels que ens movem
  //en la pantalla quan prémem una de les tecles de
  //moviment
  let avio = document.getElementById("avio");
  let boton_ayuda = document.getElementById("ayuda");
  let boton_nivel1 = document.getElementById("nivel1");
  let boton_nivel2 = document.getElementById("nivel2");
  let reves = false;
  let sonidoAudio = false;
  let audio = document.getElementById("musicaFondo");
  let audioAvion = document.getElementById("audioAvion");
  const pixels_a_moure = 15;

  audio.play();

  boton_ayuda.addEventListener("click", (event) => {
    
  });

  boton_nivel1.addEventListener("click", (event) => {
    document.body.style.backgroundImage = 'url("../fons_nivells/nivell1.jpg")';

  });
  boton_nivel2.addEventListener("click", (event) => {
    document.body.style.backgroundImage = 'url("../fons_nivells/nivell2.jpg")';
  });

  function moureEsquerra() {
    //ací agafarem la posició actual on estiga l'avió amb
    let posicion = getAvioPos();
    //i el mourem "pixels_a_moure" píxels cap a l'esquerra.
    //Ex:
    //   getAvioPos(element).left torna la posició de l'eix X de l'avió
    //   getAvioPos(element).top torna la posició de l'eix Y de l'avió
    //Per a canviar-li la posició a un element html cal
    //posar  element.style ... (cerca per internet per veure
    //quines propietats té style que estiguen relacionades amb posicions)
    //************** per completar per l'alumne *******/
    //                   todo                         */
    //*************************************************/
    if (posicion.left > 0) {
      avio.style.backgroundImage = 'url("../avion/AvionMovReves.png")';
      avio.style.left = posicion.left - pixels_a_moure + "px";
      avio.classList.add('quieto');
      sonidoAvion();
      reves = true;
    }
  }

  function moureDreta() {
    //ací agafarem la posició actual on estiga l'avió amb
    let posicion = getAvioPos();
    //i el mourem "pixels_a_moure" píxels cap a la dreta.
    //Ex:
    //   getAvioPos(element).left torna la posició de l'eix X de l'avió
    //   getAvioPos(element).top torna la posició de l'eix Y de l'avió
    //Per a canviar-li la posició a un element html cal
    //posar  element.style ... (cerca per internet per veure
    //quines propietats té style que estiguen relacionades amb posicions)
    //************** per completar per l'alumne *******/
    //                   todo                         */
    //*************************************************/
    //if (posicion.left <= document.body.style.width) {
      avio.style.backgroundImage = 'url("../avion/AvionMov.png")';
      avio.style.left = posicion.left + pixels_a_moure + "px";
      avio.classList.add('quieto');
      sonidoAvion();
      reves = false;
    //}
  }

  function moureAmunt() {
    //ací agafarem la posició actual on estiga l'avió amb
    let posicion = getAvioPos();
    //i el mourem "pixels_a_moure" píxels cap amunt.
    //Ex:
    //   getAvioPos(element).left torna la posició de l'eix X de l'avió
    //   getAvioPos(element).top torna la posició de l'eix Y de l'avió
    //Per a canviar-li la posició a un element html cal
    //posar  element.style ... (cerca per internet per veure
    //quines propietats té style que estiguen relacionades amb posicions)
    //************** per completar per l'alumne *******/
    //                   todo                         */
    //*************************************************/
    sonidoAvion();
    avio.classList.add('quieto');
    if (posicion.top > 0) {
    if (reves)
      avio.style.backgroundImage = 'url("../avion/AvionMovAltoReves.png")';
    else
      avio.style.backgroundImage = 'url("../avion/AvionMovAlto.png")';

    avio.style.top = posicion.top - pixels_a_moure + "px";
    }
    
  }

  function moureAvall() {
    //ací agafarem la posició actual on estiga l'avió amb
    let posicion = getAvioPos();
    //i el mourem "pixels_a_moure" píxels cap avall.
    //Ex:
    //   getAvioPos(element).left torna la posició de l'eix X de l'avió
    //   getAvioPos(element).top torna la posició de l'eix Y de l'avió
    //Per a canviar-li la posició a un element html cal
    //posar  element.style ... (cerca per internet per veure
    //quines propietats té style que estiguen relacionades amb posicions)
    //************** per completar per l'alumne *******/
    //                   todo                         */
    //*************************************************/
    sonidoAvion();
    avio.classList.add('quieto');
    if (reves)
      avio.style.backgroundImage = 'url("../avion/AvionMovBajoReves.png")';
    else
      avio.style.backgroundImage = 'url("../avion/AvionMovBajo.png")';

    avio.style.top = posicion.top + pixels_a_moure + "px";
  }

  function passarANumero(n) {
    return parseInt(n == "auto" ? 0 : n);
  }

  /**
   * Aquesta funció en torna una objecte amb la posició actual de l'avió a la pantalla
   * return obj.left --> posició de l'avió de l'eix X
   *        obj.top --> posició de l'avió de l'eix Y
   */
  function getAvioPos() {
    let obj = {
      left: passarANumero(getComputedStyle(avio).left),
      top: passarANumero(getComputedStyle(avio).top),
    };
    return obj;
  }

  /**
   * Funció encarregada de controlar quina tecla s'ha "apretat"
   * @param {*} evt: event que es llança
   */
  function moureAvio(evt) {
    switch (evt.keyCode) {
      case 37:
        /** hem apretat la tecla de fletxa esquerra */
        moureEsquerra();
        break;
      case 39:
        /** hem apretat la tecla de fletxa dreta */
        moureDreta();
        break;
      case 38:
        /** hem apretat la tecla de fletxa amunt */
        moureAmunt();
        break;
      case 40:
        /** hem apretat la tecla de fletxa avall */
        moureAvall();
        break;
      //************** per completar per l'alumne *******/
      //                   todo                         */
      //*************************************************/
      //mira quina tecla és el valor 1 el teclat i fes
      //que la música s'active o es desactive segons estava
      //abans activada o no activada
    }
  }
  /**
   * Funció encarregada de fer el que calga quan es pare l'avió
   */
  function pararAvio() {
    audioAvion.pause();
    avio.classList.remove('quieto');

    if (reves)
      avio.style.backgroundImage = 'url("../avion/AvionQuietoReves.png")';
    else
      avio.style.backgroundImage = 'url("../avion/AvionQuieto.png")';

  }

  function sonidoAvion(){
    audioAvion.play();
  }

  document.addEventListener("keydown", (event)=>{
    
    if(event.key === '1')
      sonidoAudio = !sonidoAudio;
    
    if(sonidoAudio)
      audio.play();
    
    else
      audio.pause();
  });
  function docReady() {
    window.addEventListener("keydown", moureAvio);
    window.addEventListener("keyup", pararAvio);
  }

});
